from sqlalchemy import Column, Integer, String, Date, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

# Читальные залы
class ReadingHall(Base):
    __tablename__ = 'reading_halls'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    specialization = Column(String)
    seats_total = Column(Integer, nullable=False)
    readers = relationship("Reader", back_populates="hall", cascade="all, delete")

# Читатели
class Reader(Base):
    __tablename__ = 'readers'
    id = Column(Integer, primary_key=True)
    full_name = Column(String, nullable=False)
    ticket_number = Column(String, unique=True, nullable=False)
    birth_date = Column(Date)
    phone = Column(String)
    education = Column(String)
    hall_id = Column(Integer, ForeignKey('reading_halls.id'))
    hall = relationship("ReadingHall", back_populates="readers")
    books = relationship("BookIssuance", back_populates="reader", cascade="all, delete")

# Книги
class Book(Base):
    __tablename__ = 'books'
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    author = Column(String, nullable=False)
    publish_year = Column(Integer)
    code = Column(String, unique=True, nullable=False)
    copies_total = Column(Integer, nullable=False)
    rating = Column(Integer, default=0)
    issuances = relationship("BookIssuance", back_populates="book", cascade="all, delete")

# Выдачи книг
class BookIssuance(Base):
    __tablename__ = 'book_issuances'
    id = Column(Integer, primary_key=True)
    book_id = Column(Integer, ForeignKey('books.id'))
    reader_id = Column(Integer, ForeignKey('readers.id'))
    issue_date = Column(Date)
    return_date = Column(Date)
    book = relationship("Book", back_populates="issuances")
    reader = relationship("Reader", back_populates="books")
