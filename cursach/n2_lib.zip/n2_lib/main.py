import streamlit as st
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from models import Base
import procedures
from datetime import datetime
import configparser

# Настройка подключения к БД
config = configparser.ConfigParser()
config.read('database.ini')
db = config['postgresql']
engine = create_engine(f"postgresql://{db['user']}:{db['password']}@{db['host']}:5432/{db['database']}")
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

# Триггеры (выполняются 1 раз)
with engine.connect() as conn:
    conn.execute(text("""
    CREATE OR REPLACE FUNCTION delete_readers_on_hall_delete()
    RETURNS TRIGGER AS $$
    BEGIN
        DELETE FROM readers WHERE hall_id = OLD.id;
        RETURN OLD;
    END;
    $$ LANGUAGE plpgsql;

    CREATE TRIGGER trg_delete_readers
    AFTER DELETE ON reading_halls
    FOR EACH ROW
    EXECUTE FUNCTION delete_readers_on_hall_delete();

    CREATE OR REPLACE FUNCTION delete_issuances_on_reader_delete()
    RETURNS TRIGGER AS $$
    BEGIN
        DELETE FROM book_issuances WHERE reader_id = OLD.id;
        RETURN OLD;
    END;
    $$ LANGUAGE plpgsql;

    CREATE TRIGGER trg_delete_issuances
    AFTER DELETE ON readers
    FOR EACH ROW
    EXECUTE FUNCTION delete_issuances_on_reader_delete();

    CREATE OR REPLACE FUNCTION delete_issuances_on_book_delete()
    RETURNS TRIGGER AS $$
    BEGIN
        DELETE FROM book_issuances WHERE book_id = OLD.id;
        RETURN OLD;
    END;
    $$ LANGUAGE plpgsql;

    CREATE TRIGGER trg_delete_issuances_book
    AFTER DELETE ON books
    FOR EACH ROW
    EXECUTE FUNCTION delete_issuances_on_book_delete();
    """))

# Streamlit интерфейс
st.set_page_config(page_title="Библиотека", layout="wide")
st.title("📚 Система управления библиотекой")

menu = st.sidebar.selectbox("Меню", [
    "📘 Книги у читателей",
    "📗 Свободные места в залах",
    "📕 Доступность книги",
    "📙 Книги автора в зале",
    "👤 Читатели с книгами в 1 экземпляре",
    "🌟 Книги с максимальным рейтингом",
    "➕ Зарегистрировать читателя",
    "❌ Списать книгу",
    "📦 Добавить экземпляры книги"
])

output_lines = []

def gui_print(text):
    output_lines.append(text)

# Подключение вывода к Streamlit
procedures.print = gui_print

# Действия
if menu == "📘 Книги у читателей":
    output_lines.clear()
    procedures.books_per_reader(session)
    st.text_area("Результат", "\n".join(output_lines), height=400)

elif menu == "📗 Свободные места в залах":
    output_lines.clear()
    procedures.free_seats_per_hall(session)
    st.text_area("Результат", "\n".join(output_lines), height=300)

elif menu == "📕 Доступность книги":
    book_id = st.number_input("ID книги", min_value=1, step=1)
    if st.button("Проверить"):
        output_lines.clear()
        procedures.can_issue_book(session, book_id)
        st.text_area("Результат", "\n".join(output_lines), height=120)

elif menu == "📙 Книги автора в зале":
    author = st.text_input("Автор")
    hall_id = st.number_input("ID зала", min_value=1, step=1)
    if st.button("Показать"):
        output_lines.clear()
        procedures.books_by_author_in_hall(session, author, hall_id)
        st.text_area("Результат", "\n".join(output_lines), height=120)

elif menu == "👤 Читатели с книгами в 1 экземпляре":
    output_lines.clear()
    procedures.readers_with_unique_books(session)
    st.text_area("Результат", "\n".join(output_lines), height=300)

elif menu == "🌟 Книги с максимальным рейтингом":
    output_lines.clear()
    procedures.top_rated_books(session)
    st.text_area("Результат", "\n".join(output_lines), height=300)

elif menu == "➕ Зарегистрировать читателя":
    with st.form("new_reader"):
        name = st.text_input("ФИО")
        ticket = st.text_input("Номер билета")
        bdate = st.date_input("Дата рождения")
        phone = st.text_input("Телефон")
        edu = st.text_input("Образование")
        hall_id = st.number_input("ID зала", min_value=1, step=1)
        if st.form_submit_button("Добавить"):
            output_lines.clear()
            procedures.register_reader(session, name, ticket, bdate, phone, edu, hall_id)
            st.success("Читатель добавлен")
            st.text_area("Результат", "\n".join(output_lines), height=100)

elif menu == "❌ Списать книгу":
    book_id = st.number_input("ID книги", min_value=1, step=1)
    if st.button("Списать"):
        output_lines.clear()
        procedures.write_off_book(session, book_id)
        st.text_area("Результат", "\n".join(output_lines), height=100)

elif menu == "📦 Добавить экземпляры книги":
    book_id = st.number_input("ID книги", min_value=1, step=1)
    count = st.number_input("Сколько добавить", min_value=1, step=1)
    if st.button("Добавить"):
        output_lines.clear()
        procedures.add_copies(session, book_id, count)
        st.text_area("Результат", "\n".join(output_lines), height=100)
