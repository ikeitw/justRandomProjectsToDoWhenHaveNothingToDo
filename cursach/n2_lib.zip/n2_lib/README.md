# 📚 Система управления библиотекой (Python + PostgreSQL + SQLAlchemy)

## 📦 Описание
Программа позволяет управлять читателями, книгами и читальными залами, а также выдавать и учитывать книги.

---

## 🚀 Быстрый старт

### 1. Установите зависимости
```bash
pip install -r requirements.txt
```

### 2. Создайте базу данных PostgreSQL
```sql
CREATE DATABASE librarydb;
```

### 3. Настройте `database.ini`
```ini
[postgresql]
host=localhost
database=librarydb
user=postgres
password=ВАШ_ПАРОЛЬ
```

### 4. Заполните БД тестовыми данными
```bash
python db.py
```

### 5. Запустите графическое меню
```bash
streamlit run main.py
```

---

## 🗂 Структура проекта

| Файл            | Описание                           |
|-----------------|------------------------------------|
| `models.py`     | Структура таблиц SQLAlchemy        |
| `procedures.py` | Библиотечные функции и действия    |
| `main.py`       | Графическое меню + триггеры        |
| `db.py`         | Заполнение базы тестовыми данными  |
| `database.ini`  | Настройки подключения к PostgreSQL |
| `requirements.txt` | Необходимые зависимости Python     |
