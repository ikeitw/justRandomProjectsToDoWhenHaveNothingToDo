from sqlalchemy.orm import sessionmaker
from models import Base, ReadingHall, Reader, Book, BookIssuance
from sqlalchemy import create_engine
import configparser
from datetime import date, timedelta

# Чтение конфигурации
config = configparser.ConfigParser()
config.read('database.ini')
db = config['postgresql']

# Подключение к БД
engine = create_engine(f"postgresql://{db['user']}:{db['password']}@{db['host']}:5432/{db['database']}")
Session = sessionmaker(bind=engine)
session = Session()

# Очистка и пересоздание таблиц
Base.metadata.drop_all(engine)
Base.metadata.create_all(engine)

# Добавление залов
halls = [
    ReadingHall(name="Общий зал", specialization="Общая литература", seats_total=20),
    ReadingHall(name="Физико-Математический", specialization="Физика и математика", seats_total=15),
    ReadingHall(name="Исторический зал", specialization="История", seats_total=10)
]
session.add_all(halls)
session.commit()

# Добавление читателей
readers = [
    Reader(full_name="Иванов Иван", ticket_number="A001", birth_date=date(1990, 5, 15), phone="123456", education="Высшее", hall_id=halls[0].id),
    Reader(full_name="Петров Петр", ticket_number="A002", birth_date=date(1985, 8, 20), phone="654321", education="Среднее", hall_id=halls[1].id),
    Reader(full_name="Сидоров Сидор", ticket_number="A003", birth_date=date(2000, 1, 10), phone="987654", education="Студент", hall_id=halls[2].id)
]
session.add_all(readers)
session.commit()

# Добавление книг
books = [
    Book(title="Физика 101", author="Ньютон И.", publish_year=2000, code="PH-001", copies_total=3, rating=5),
    Book(title="Математика для всех", author="Эйлер Л.", publish_year=1995, code="MT-001", copies_total=1, rating=4),
    Book(title="История древнего мира", author="Геродот", publish_year=1980, code="HI-001", copies_total=2, rating=3),
    Book(title="Книга жизни", author="Достоевский Ф.", publish_year=1870, code="LI-001", copies_total=1, rating=5),
    Book(title="Алгебра для начинающих", author="Гаусс К.", publish_year=2010, code="MT-002", copies_total=4, rating=4)
]
session.add_all(books)
session.commit()

# Выдачи книг
issuances = [
    BookIssuance(book_id=books[0].id, reader_id=readers[0].id, issue_date=date.today() - timedelta(days=3)),
    BookIssuance(book_id=books[1].id, reader_id=readers[1].id, issue_date=date.today() - timedelta(days=5)),
    BookIssuance(book_id=books[3].id, reader_id=readers[2].id, issue_date=date.today() - timedelta(days=1))
]
session.add_all(issuances)
session.commit()

print("✅ База данных успешно заполнена данными.")
