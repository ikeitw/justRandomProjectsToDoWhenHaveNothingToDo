from models import *
from sqlalchemy.orm import Session

# 📘 1. Какие книги выданы каждому читателю
def books_per_reader(session: Session):
    readers = session.query(Reader).all()
    for r in readers:
        print(f"Читатель: {r.full_name} (Билет №{r.ticket_number})")
        for issue in r.books:
            print(f"  Книга: {issue.book.title} — Автор: {issue.book.author} — Выдана: {issue.issue_date}")

# 📘 2. Сколько свободных мест в каждом зале
def free_seats_per_hall(session: Session):
    halls = session.query(ReadingHall).all()
    for h in halls:
        occupied = len(h.readers)
        free = h.seats_total - occupied
        print(f"Зал: {h.name} — Свободных мест: {free}/{h.seats_total}")

# 📘 3. Можно ли выдать книгу (есть ли экземпляры)
def can_issue_book(session: Session, book_id):
    book = session.query(Book).filter_by(id=book_id).first()
    if not book:
        print("Книга не найдена.")
        return
    issued = session.query(BookIssuance).filter_by(book_id=book.id).filter(BookIssuance.return_date == None).count()
    available = book.copies_total - issued
    print(f"Книга: {book.title} — Свободно экземпляров: {available}")
    return available > 0

# 📘 4. Количество книг заданного автора в читальном зале
def books_by_author_in_hall(session: Session, author, hall_id):
    hall = session.query(ReadingHall).filter_by(id=hall_id).first()
    if not hall:
        print("Зал не найден.")
        return
    books = session.query(Book).filter_by(author=author).all()
    count = 0
    for b in books:
        for issue in b.issuances:
            if issue.reader and issue.reader.hall_id == hall_id:
                count += 1
    print(f"Книг автора {author} в зале {hall.name}: {count}")

# 📘 5. Читатели, взявшие книги, имеющиеся в одном экземпляре
def readers_with_unique_books(session: Session):
    books = session.query(Book).filter_by(copies_total=1).all()
    for b in books:
        for issue in b.issuances:
            if issue.return_date is None:
                print(f"Книга: {b.title} — Читатель: {issue.reader.full_name}")

# 📘 6. Книги с максимальным рейтингом
def top_rated_books(session: Session):
    max_rating = session.query(Book).order_by(Book.rating.desc()).first()
    if not max_rating:
        print("Нет книг.")
        return
    top_books = session.query(Book).filter_by(rating=max_rating.rating).all()
    for b in top_books:
        print(f"{b.title} — Автор: {b.author} — Рейтинг: {b.rating}")

# 🧾 7. Записать нового читателя
def register_reader(session: Session, full_name, ticket_number, birth_date, phone, education, hall_id):
    reader = Reader(
        full_name=full_name,
        ticket_number=ticket_number,
        birth_date=birth_date,
        phone=phone,
        education=education,
        hall_id=hall_id
    )
    session.add(reader)
    session.commit()
    print("Читатель зарегистрирован.")

# 🧾 8. Списать книгу
def write_off_book(session: Session, book_id):
    book = session.query(Book).filter_by(id=book_id).first()
    if book:
        session.delete(book)
        session.commit()
        print("Книга списана.")
    else:
        print("Книга не найдена.")

# 🧾 9. Принять книгу в фонд (добавить экземпляры)
def add_copies(session: Session, book_id, additional):
    book = session.query(Book).filter_by(id=book_id).first()
    if book:
        book.copies_total += additional
        session.commit()
        print(f"Добавлено {additional} экземпляров книги: {book.title}")
    else:
        print("Книга не найдена.")
